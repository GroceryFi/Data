<?php defined('ABSPATH') || exit;

/**
 * Plugin Name: Binance Pay for WooCommerce
 * Version:     1.0.1
 * Plugin URI:  https://beycanpress.com/
 * Description: Binance Pay payment gateway for WooCommerce
 * Author:      BeycanPress
 * Author URI:  https://beycanpress.com
 * License:     GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
 * Text Domain: binance_pay_gateway
 * Domain Path: /languages
 * Tags:        Binance Pay, Cryptocurrency, WooCommerce, WordPress, Ethereum, Bitcoin, Payment, Gateway, Plugin
 * Requires at least: 5.0
 * Tested up to: 6.1
 * Requires PHP: 7.4
*/

require __DIR__ . '/vendor/autoload.php';


add_action('admin_footer', function() {
	if (!get_option('cryptopay_new_version_promotionx')) {
    	update_option('cryptopay_new_version_promotionx', true);
        ?>
        <div class="cp-video-modal">
            <div class="modal-content">
                <div class="close-btn">
                    X
                </div>
                <div>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/3vaoFL4XG10" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    <div class="buttons">
                        <a href="https://bit.ly/cplitebuynow" target="_blank" class="button"><?php echo __('Buy premium', 'cryptopay'); ?></a>
                        <a href="https://bit.ly/3pOiY25" target="_blank" class="button"><?php echo __('Review now', 'cryptopay'); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .cp-video-modal {
                position: fixed;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .cp-video-modal .modal-content  {
                width: auto;
                max-width: 100%;
                padding: 40px;
                background-color: #fff;
                position: relative;
            }
            .cp-video-modal .modal-content .close-btn {
                position: absolute;
                right: 10px;
                top: 10px;
                cursor: pointer;
                font-weight: 600;
                font-size: 20px;
                color: #000;
            }
            .cp-video-modal .modal-content .buttons {
                position: relative;
                display: flex;
                justify-content: space-between;
                margin-top: 20px;
            }
            .cp-video-modal .modal-content iframe {
                max-width: 100%;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                $('.cp-video-modal .close-btn').click(function() {
                    $('.cp-video-modal').hide();
                });
            });
        </script>
        <?php
	}
});

add_action('plugins_loaded', function () {
    add_filter('woocommerce_payment_gateways', function($gateways) {
        $gateways[] = \BeycanPress\BinancePay\Gateway::class;
        return $gateways;
    });
});