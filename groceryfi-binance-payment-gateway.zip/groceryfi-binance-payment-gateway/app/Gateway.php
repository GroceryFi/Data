<?php 

namespace BeycanPress\BinancePay;

class Gateway extends \WC_Payment_Gateway
{   
    /**
     * @var string
     */
    public static $gateway = 'binance_pay_gateway';

    /**
     * @return void
     */
    public function __construct()
    {
        $this->id = self::$gateway;
        $this->method_title = esc_html__('Binance Pay', 'binance_pay_gateway');
        $this->method_description = esc_html__('Binance Pay payment gateway', 'binance_pay_gateway');

        $this->supports = ['products'];

        $this->init_form_fields();

        $this->init_settings();
        $this->title = $this->get_option('title');
        $this->enabled = $this->get_option('enabled');
        $this->description = $this->get_option('description');
        $this->order_button_text = $this->get_option('order_button_text');

        $callback = new Callback();
		add_action('woocommerce_api_binance-pay-gateway/callback', [$callback, 'init']);
		add_action('woocommerce_api_binance-pay-gateway/webhook', [$callback, 'webhook']);
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    /**
     * @return void
     */
    public function init_form_fields() : void
    {
        $this->form_fields = array(
            'enabled' => array(
                'title'       => esc_html__('Enable/Disable', 'binance_pay_gateway'),
                'label'       => esc_html__('Enable', 'binance_pay_gateway'),
                'type'        => 'checkbox',
                'default'     => 'no'
            ),
            'title' => array(
                'title'       => esc_html__('Title', 'binance_pay_gateway'),
                'type'        => 'text',
                'description' => esc_html__('This controls the title which the user sees during checkout.', 'binance_pay_gateway'),
                'default'     => esc_html__('Pay with Binance Pay', 'binance_pay_gateway')
            ),
            'description' => array(
                'title'       => esc_html__('Description', 'binance_pay_gateway'),
                'type'        => 'textarea',
                'description' => esc_html__('This controls the description which the user sees during checkout.', 'binance_pay_gateway'),
                'default'     => esc_html__('Pay with Binance Pay', 'binance_pay_gateway'),
            ),
            'order_button_text' => array(
                'title'       => esc_html__('Order button text', 'binance_pay_gateway'),
                'type'        => 'text',
                'description' => esc_html__('Pay button on the checkout page', 'binance_pay_gateway'),
                'default'     => esc_html__('Pay with Binance Pay', 'binance_pay_gateway'),
            ),
            'payment_complete_order_status' => array(
                'title'   => esc_html__('Payment complete order status', 'binance_pay_gateway'),
                'type'    => 'select',
                'help'    => esc_html__('The status to apply for order after payment is complete.', 'binance_pay_gateway'),
                'options' => [
                    'wc-completed' => esc_html__('Completed', 'binance_pay_gateway'),
                    'wc-processing' => esc_html__('Processing', 'binance_pay_gateway')
                ],
                'default' => 'wc-completed',
            ),
			'api_key' => array(
				'title'       => esc_html__('API Key (Merchant)', 'binance_pay_gateway'),
				'type'        => 'text',
				'description' => esc_html__('Provide the merchant API key from your BinancePay merchant account.', 'binance_pay_gateway'),
				'default'     => null,
				'desc_tip'    => true,
            ),
			'api_secret' => array(
				'title'       => esc_html__('API Secret', 'binance_pay_gateway'),
				'type'        => 'password',
				'description' => esc_html__('Provide the merchant API secret from your BinancePay merchant account.', 'binance_pay_gateway'),
				'default'     => null,
				'desc_tip'    => true,
            ),
            'binance_webhook_url' => array(
                'title'       => esc_html__('Webhook URL: ', 'binance_pay_gateway') . home_url('wc-api/binance-pay-gateway/webhook'),
                'type'        => 'title',
                'description' => esc_html__('Binance "merchant_callback_url" webhook endpoint', 'binance_pay_gateway'),
            ),
        );
    }

    public function process_admin_options() {
		parent::process_admin_options();

		try {
            $binanceService = new BinanceService();
			$sertifcates = $binanceService->getSertificate();

			if (!isset($sertifcates->certSerial, $sertifcates->certPublic)) {
				Notice::addNotice('error', 'No certificate (for validating webhooks) returned from Binance.');
			}

			$this->update_option('certserial', $sertifcates->certSerial);
			$this->update_option('certpublic', $sertifcates->certPublic);

			Notice::addNotice('success', 'Successfully fetched certificate (for validating webhooks) from Binance.');

		} catch (\Throwable $e) {
			Notice::addNotice('error', 'Error fetching certificate from Binance.' . $e->getMessage());
		}

	}

    /**
     * @param string $key
     * @return string|null
     */
    public static function get_option_custom(string $key) : ?string
    {
        $options = get_option('woocommerce_'.self::$gateway.'_settings');
        return isset($options[$key]) ? $options[$key] : null;
    }

    /**
     * @return mixed
     */
    public function get_icon() : string
    {
        return '<img src="'.plugins_url('assets/images/logo.png', dirname(__FILE__)).'" alt="Binance Pay" />';
    }

    /**
     * @return void
     */
    public function payment_fields() : void
    {
        echo $this->description;
    }

    /**
     * @param int $orderId
     * @return array
     */
    public function process_payment($orderId) : array
    {
        $order = new \WC_Order($orderId);

		try {
            $binanceService = new BinanceService();
			$result = $binanceService->createOrder($order);
        
			$order->update_meta_data('binance_order_id', $result->prepayId);
			$order->save();

            $order->update_status('wc-pending', esc_html__('Payment is awaited.', 'binance_pay_gateway'));

            $order->add_order_note(esc_html__('Customer has chosen Binance Pay payment method, payment is pending.', 'binance_pay_gateway'));
    
			return [
				'result'   => 'success',
				'redirect' => $result->universalUrl,
				'orderId' => $order->get_id(),
			];

		} catch (\Exception $e) {
			wc_add_notice($e->getMessage(), 'error');
		}

		return [
			'result' => false
		];
    }    

	/**
     * @param string $key
     * @return string|null
     */
    public static function getOption(string $key) : ?string
    {
        $options = get_option('woocommerce_'.self::$gateway.'_settings');
        return isset($options[$key]) ? $options[$key] : null;
    }
}